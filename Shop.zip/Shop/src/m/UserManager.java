package m;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import c.GlobalData;



public class UserManager
{
	public static ArrayList<UserDB> getAllUser()
	{
		ArrayList<UserDB> list = new ArrayList<UserDB>();

		try
		{
			// create our mysql database connection
			Class.forName("com.mysql.jdbc.Driver");
			Connection	connect = DriverManager.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect
				
			// our SQL SELECT query.
			// if you only need a few columns, specify them by name instead of using "*"
			String query = "SELECT * FROM UserDB";

			// create the java statement
			Statement st = connect.createStatement();

			// execute the query, and get a java resultset
			ResultSet rs = st.executeQuery(query);

			// iterate through the java resultset
			while (rs.next())
			{
				int id = rs.getInt("id");
				String username = rs.getString("username");
				String password = rs.getString("password");
				String usertype = rs.getString("usertype");

				UserDB cc = new UserDB(id, username, password, usertype);
				list.add(cc);
				// print the results
				System.out.format("%s, %s, %s, %s \n", id, username, password, usertype);
			}
			st.close();
		} catch (Exception e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
		return list;
	}

	public static void saveUser(UserDB x)
	{
		try
		{
			// create our mysql database connection
			Class.forName("com.mysql.jdbc.Driver");
			Connection	connect = DriverManager.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect
				
			// our SQL SELECT query.
			// if you only need a few columns, specify them by name instead of using "*"
			String query = "INSERT INTO UserDB VALUES(0, '" + x.username + "' , '" + x.password + "', '" + x.usertype
					+ "')";

			// create the java statement
			Statement st = connect.createStatement();
			st.executeUpdate(query);
			st.close();

		} catch (Exception e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
	}

	public static void editUser(UserDB x)
	{
		try
		{
			// create our mysql database connection
			Class.forName("com.mysql.jdbc.Driver");
			Connection	connect = DriverManager.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect
			
			// our SQL SELECT query.
			// if you only need a few columns, specify them by name instead of using "*"
			String query = "UPDATE UserDB SET username = '" + x.username + "' ,password = '" + x.password
					+ "',usertype = '" + x.usertype + "'WHERE id = " + x.id + " ";

			// create the java statement
			Statement st = connect.createStatement();
			st.executeUpdate(query);
			st.close();

		} catch (Exception e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
	}

	public static void deleteUser(UserDB x)
	{
		try
		{
			// create our mysql database connection
			Class.forName("com.mysql.jdbc.Driver");
			Connection	connect = DriverManager.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect
			
			// our SQL SELECT query.
			// if you only need a few columns, specify them by name instead of using "*"
			String query = "DELETE FROM UserDB WHERE ID = " + x.id + " ";

			// create the java statement
			Statement st = connect.createStatement();
			st.executeUpdate(query);
			st.close();

		} catch (Exception e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
	}

	public static boolean cheklogin(String username, String password)
	{

		
		ArrayList<UserDB> list = new ArrayList<UserDB>();

		try
		{
			// create our mysql database connection
			Class.forName("com.mysql.jdbc.Driver");
			Connection	connect = DriverManager.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect
			
			// our SQL SELECT query.
			// if you only need a few columns, specify them by name instead of using "*"
			String query = "SELECT * FROM UserDB WHERE username = ? AND password = ? ";
			
			// create the java statement
			//PreparedStatement 
			PreparedStatement st = connect.prepareStatement(query);
			
			st.setString(1, username);
			st.setString(2, password);
			ResultSet rs = st.executeQuery();
			// iterate through the java resultset
			while (rs.next())
			{
				GlobalData.CurrentUser_userID = rs.getInt(1);
				GlobalData.CurrentUser_username = rs.getString(2);
				GlobalData.CurrentUser_usertype = rs.getString(4);
				return true;
			}
			st.close();
		} catch (Exception e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return false;
	}

}
