package m;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.imageio.ImageIO;


public class ProductManager
{
	public static ArrayList<ProductDB> getAllProduct() throws SQLException, IOException
	{
		ArrayList<ProductDB> list = new ArrayList<ProductDB>();

		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect
			// database
			// System.out.println("test2");
			// s = connect.createStatement();

			String query = "SELECT * FROM ProductDB";

			Statement st = connect.createStatement();

			// execute the query, and get a java resultset
			ResultSet rs = st.executeQuery(query);

			// iterate through the java resultset
			while (rs.next())
			{
				int id = rs.getInt("product_id");
				String pName = rs.getString("product_name");
				Double price = rs.getDouble("price_per_unit");
				String dresc = rs.getString("product_description");
				byte[] img_byte = rs.getBytes("product_image");
				BufferedImage bufferedimg = null;
				if (img_byte == null || img_byte.length == 0)
				{

				} else
				{
					ByteArrayInputStream bais = new ByteArrayInputStream(img_byte);
					bufferedimg = ImageIO.read(bais);
					bais.close();
				}

				ProductDB cc = new ProductDB(id, pName, price, dresc, bufferedimg);
				list.add(cc);
			}
			st.close();
		} catch (ClassNotFoundException e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		} // call driver
			// System.out.println("test");
		return list;
	}

	public static void saveProduct(ProductDB x)
	{
		try
		{
			// create our mysql database connection
			Class.forName("com.mysql.jdbc.Driver");
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect

			String query = "INSERT INTO ProductDB VALUES(?, ? , ? , ? , ? )";

			// ���prepareStatement error ���仴���� import prepareStatement��.sql ������
			PreparedStatement st = connect.prepareStatement(query);
			st.setInt(1, 0);
			st.setString(2, x.product_name);
			st.setDouble(3, x.price_per_unit);
			st.setString(4, x.product_description);
			if (x.product_image != null)
			{
				ByteArrayOutputStream outStream = new ByteArrayOutputStream();
				ImageIO.write(x.product_image, "png", outStream); // ��¹�������productimg ŧ outputstream
				byte[] buffer = outStream.toByteArray();
				st.setBytes(5, buffer);
				outStream.close();
			} else
			{
				byte[] buffer = new byte[0];
				st.setBytes(5, buffer);
			}

			st.executeUpdate();

			st.close();

		} catch (Exception e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
	}

	public static void editProductImage(ProductDB x)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect

			String query = "UPDATE ProductDB SET product_image = ? WHERE product_id = ?";

			PreparedStatement st = connect.prepareStatement(query);

			if (x.product_image != null)
			{
				ByteArrayOutputStream outStream = new ByteArrayOutputStream();
				ImageIO.write(x.product_image, "png", outStream); // ��¹�������productimg ŧ outputstream
				byte[] buffer = outStream.toByteArray();
				st.setBytes(1, buffer);
				outStream.close();
			} else
			{
				byte[] buffer = new byte[0];
				st.setBytes(5, buffer);
			}

			st.setInt(2, x.product_id);
			st.executeUpdate();
			st.close();

		} catch (Exception e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
	}

	public static void editProduct(ProductDB x)
	{
		try
		{
			// create our mysql database connection
			Class.forName("com.mysql.jdbc.Driver");
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect

			// our SQL SELECT query.
			// if you only need a few columns, specify them by name instead of using "*"
			String query = "UPDATE ProductDB SET product_name = '" + x.product_name + "' , price_per_unit = '"
					+ x.price_per_unit + "'" + ", product_description = '" + x.product_description
					+ "' WHERE product_id = " + x.product_id + " ";

			System.out.println(query);
			// create the java statement
			Statement st = connect.createStatement();
			st.executeUpdate(query);
			st.close();

			editProductImage(x);
		} catch (Exception e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}

		// UPDATE `products` SET `product_name` = 'gro', `price_per_unit` = '1500' WHERE
		// `products`.`product_id` = 3;
		// UPDATE `products` SET `product_image` =

	}

	public static void deleteProduct(ProductDB x)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection connect = DriverManager
					.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect

			// our SQL SELECT query.
			// if you only need a few columns, specify them by name instead of using "*"
			String query = "DELETE FROM ProductDB WHERE product_id = " + x.product_id + " ";
			System.out.println(query);

			// create the java statement
			Statement st = connect.createStatement();
			st.executeUpdate(query);
			st.close();

		} catch (Exception e)
		{
			System.err.println("Got an exception! ");
			System.err.println(e.getMessage());
		}
	}

}
