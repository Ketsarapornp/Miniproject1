package m;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



public class CustomerManager

{
	public static ArrayList<CustomerDB> getAllCustomer() throws SQLException
	{
		ArrayList<CustomerDB> list = new ArrayList<CustomerDB>();
		Connection connect = null;
		Statement s = null;
		

		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			connect = DriverManager.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect
																													// database
			// System.out.println("test2");
			s = connect.createStatement();

			String query = "SELECT * FROM CustomerDB";

			Statement st = connect.createStatement();

			// execute the query, and get a java resultset
			ResultSet rs = st.executeQuery(query);

			// iterate through the java resultset
			while (rs.next())
			{
				int id = rs.getInt("id");
				String firstName = rs.getString("name");
				String lastName = rs.getString("surname");
				String phone = rs.getString("phone");

				CustomerDB cc = new CustomerDB(id, firstName, lastName, phone);
				list.add(cc);
				// print the results
				System.out.format("%s, %s, %s, %s \n", id, firstName, lastName, phone);
			}
			st.close();
		} catch (ClassNotFoundException e)
		{
			System.err.println("Got an exception! ");
		      System.err.println(e.getMessage());
		} // call driver
			// System.out.println("test");

		return list;
	}
	
	public static ArrayList<CustomerDB> SearchAllCustomer(String s)
	{
		ArrayList<CustomerDB> list = new ArrayList<CustomerDB>();
		Connection connect = null;
		//Statement s = null;
		
		try
	    {
			Class.forName("com.mysql.jdbc.Driver");
			connect = DriverManager.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect
																													// database
			// System.out.println("test2");
			//s = connect.createStatement();
	      
	      String query = "SELECT * FROM CustomerDB WHERE name LIKE '"+s+"' OR surname LIKE '"+s+"'";

	      Statement st = connect.createStatement();
	      
	      ResultSet rs = st.executeQuery(query);
	      
	      while (rs.next())
	      {
	        int id = rs.getInt("id");
	        String firstName = rs.getString("name");
	        String lastName = rs.getString("surname");
	        String phone = rs.getString("phone");
	        
	        CustomerDB cc = new CustomerDB (id,firstName,lastName,phone);
	        list.add(cc);
	        // print the results
	        System.out.format("%s, %s, %s, %s \n", id, firstName, lastName, phone);
	      }
	      st.close();
	    }
	    catch (Exception e)
	    {
	      System.err.println("Got an exception! ");
	      System.err.println(e.getMessage());
	    }
		return list;
	}
	public static void saveNewCustomer(CustomerDB x)
	{		//Connection connect = null;
		try
	    {
	      // create our mysql database connection
			Class.forName("com.mysql.jdbc.Driver");
			Connection	connect = DriverManager.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect
																	
	      // our SQL SELECT query. 
	      // if you only need a few columns, specify them by name instead of using "*"
	      String query = "INSERT INTO CustomerDB VALUES(0, '"+x.name+"' , '" +x.surname+"', '"+x.phone+"')";

	      // create the java statement
	      Statement st = connect.createStatement();
	      	st.executeUpdate(query);
	      st.close();
	      
	    }
	    catch (Exception e)
	    {
	      System.err.println("Got an exception! ");
	      System.err.println(e.getMessage());
	    }
	}
	
	public static void editCustomer(CustomerDB x)
	{		
		try
	    {
	      // create our mysql database connection
			Class.forName("com.mysql.jdbc.Driver");
			Connection	connect = DriverManager.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect
				
	      // our SQL SELECT query. 
	      // if you only need a few columns, specify them by name instead of using "*"
	      String query = "UPDATE CustomerDB SET name = '"+x.name+"' ,surname = '" +x.surname+"',phone = '"+x.phone+"'WHERE id = "+x.id+" ";

	      // create the java statement
	      Statement st = connect.createStatement();
	      	st.executeUpdate(query);
	      st.close();
	      
	    }
	    catch (Exception e)
	    {
	      System.err.println("Got an exception! ");
	      System.err.println(e.getMessage());
	    }
	}
	
	public static void deleteCustomer(CustomerDB x)
	{		
		try
	    {
	      // create our mysql database connection
			Class.forName("com.mysql.jdbc.Driver");
			Connection	connect = DriverManager.getConnection("jdbc:mysql://localhost:8889/Shop?user=root&password=root"); // connect
				
	      // our SQL SELECT query. 
	      // if you only need a few columns, specify them by name instead of using "*"
	      String query = "DELETE FROM CustomerDB WHERE ID = " +x.id+" ";

	      // create the java statement
	      Statement st = connect.createStatement();
	      	st.executeUpdate(query);
	      st.close();
	      
	    }
	    catch (Exception e)
	    {
	      System.err.println("Got an exception! ");
	      System.err.println(e.getMessage());
	    }
	}
	public static void main(String[] args) throws SQLException
	{
		ArrayList<CustomerDB> ll =getAllCustomer();
		System.out.println(ll.size());
	}


}
