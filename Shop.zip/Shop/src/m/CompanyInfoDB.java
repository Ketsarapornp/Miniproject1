package m;

public class CompanyInfoDB
{
	public int id;
	public String company_name;
	public String address;
	public String phone;
	public String email;

}
