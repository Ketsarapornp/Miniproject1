package v;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.DefaultTableModel;

import m.CustomerDB;
import m.CustomerManager;
import m.ProductDB;
import m.ProductManager;


import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JTextField;
import javax.swing.UIManager;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextPane;
import java.sql.SQLException;

public class ProductFrame extends JFrame
{

	private JPanel contentPane;
	private JTextField textField_id;
	private JTextField textField_name;
	private JTextField textField_price;
	private JTable table;
	private JTextField textField_des;
	private ImagePanel ImagePanel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					ProductFrame frame = new ProductFrame();
					frame.setVisible(true);
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	ArrayList<ProductDB> list;

	public ProductFrame()
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 905, 549);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(21, 48, 452, 460);
		contentPane.add(scrollPane);

		table = new JTable();
		table.addMouseListener(new MouseAdapter()
		{
			@Override
			public void mouseClicked(MouseEvent e)
			{
				if (table.getSelectedRowCount() < 1)
					return;
				int index = table.getSelectedRow();
				int product_id = Integer.parseInt(table.getValueAt(index, 0).toString());
				String product_name = table.getValueAt(index, 1).toString();
				String price_per_unit = table.getValueAt(index, 2).toString();
				String product_description = table.getValueAt(index, 3).toString();
				BufferedImage img = list.get(index).product_image;
				if (img != null)
				{
					ImagePanel.setImage(img);
				}

				textField_id.setText("" + product_id);
				textField_name.setText("" + product_name);
				textField_price.setText("" + price_per_unit);
				textField_des.setText("" + product_description);
				load();
			}
			
		});
		scrollPane.setViewportView(table);

		JLabel lblId = new JLabel("ID");
		lblId.setBounds(490, 30, 61, 16);
		contentPane.add(lblId);

		JLabel lblName = new JLabel("Name");
		lblName.setBounds(490, 64, 61, 16);
		contentPane.add(lblName);

		JLabel lblPriceperunit = new JLabel("Price_per_unit");
		lblPriceperunit.setBounds(490, 101, 110, 16);
		contentPane.add(lblPriceperunit);

		JLabel lblDescription = new JLabel("Description");
		lblDescription.setBounds(490, 141, 99, 16);
		contentPane.add(lblDescription);

		JLabel lblImage = new JLabel("Image");
		lblImage.setBounds(485, 215, 61, 16);
		contentPane.add(lblImage);

		textField_id = new JTextField();
		textField_id.setBounds(611, 25, 248, 26);
		contentPane.add(textField_id);
		textField_id.setColumns(10);

		textField_name = new JTextField();
		textField_name.setColumns(10);
		textField_name.setBounds(611, 59, 248, 26);
		contentPane.add(textField_name);

		textField_price = new JTextField();
		textField_price.setColumns(10);
		textField_price.setBounds(611, 96, 248, 26);
		contentPane.add(textField_price);

		textField_des = new JTextField();
		textField_des.setBounds(611, 141, 248, 59);
		contentPane.add(textField_des);
		textField_des.setColumns(10);

		ImagePanel = new ImagePanel();
		ImagePanel.setBounds(538, 212, 345, 211);
		contentPane.add(ImagePanel);

		JButton button_1 = new JButton("Save");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(! textField_price.getText().trim().matches("[-+]?\\d*\\.?\\d+"))
				{
					JOptionPane.showMessageDialog(ProductFrame.this, "number only please");
					textField_price.requestFocus();
					textField_price.selectAll();
				}
				ProductDB x = new ProductDB();
				x.product_id = 0;
				x.product_name = textField_name.getText().trim();
				x.price_per_unit = Double.parseDouble(textField_price.getText().trim());
				x.product_description = textField_des.getText().trim();
				x.product_image = (BufferedImage)ImagePanel.getImage();
				//trim ��͡�õѴspace ��Ƿ��� 
				
				ProductManager.saveProduct(x);
				load();
				textField_id.setText("");
				textField_name.setText("");
				textField_price.setText("");
				textField_des.setText("");
				
				
				JOptionPane.showMessageDialog(ProductFrame.this, "User saved");

			}
		});
		button_1.setBounds(483, 479, 117, 29);
		contentPane.add(button_1);

		JButton button_2 = new JButton("Edit");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProductDB x = new ProductDB();
				x.product_id = Integer.parseInt( textField_id.getText().trim());
				x.product_name = textField_name.getText().trim();
				x.price_per_unit = Double.parseDouble(textField_price.getText().trim());
				x.product_description = textField_des.getText().trim();
				x.product_image = (BufferedImage)ImagePanel.getImage();
				//trim ��͡�õѴspace ��Ƿ��� 
				
				ProductManager.editProduct(x);
		
				textField_id.setText("");
				textField_name.setText("");
				textField_price.setText("");
				textField_des.setText("");
				
				
				JOptionPane.showMessageDialog(ProductFrame.this, "Product updated");

				load();
			}
		});
		button_2.setBounds(613, 479, 117, 29);
		contentPane.add(button_2);

		JButton button = new JButton("Delete");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				ProductDB x = new ProductDB();
				x.product_id = Integer.parseInt( textField_id.getText().trim());
				x.product_name = textField_name.getText().trim();
				x.price_per_unit = Double.parseDouble(textField_price.getText().trim());
				x.product_description = textField_des.getText().trim();
				x.product_image = (BufferedImage)ImagePanel.getImage();
				//trim ��͡�õѴspace ��Ƿ��� 
				
				ProductManager.deleteProduct(x);
		
				textField_id.setText("");
				textField_name.setText("");
				textField_price.setText("");
				textField_des.setText("");
				
				JOptionPane.showMessageDialog(ProductFrame.this, "Product deleted");
				load();
			}
		});
		button.setBounds(742, 479, 117, 29);
		contentPane.add(button);

		JButton btnBrowseImg = new JButton("Load Image");
		btnBrowseImg.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser fc = new JFileChooser();
				fc.addChoosableFileFilter(new OpenFileFilter("jpeg", "Photo in JPEG format"));
				fc.addChoosableFileFilter(new OpenFileFilter("jpg", "Photo in JPEG format"));
				fc.addChoosableFileFilter(new OpenFileFilter("png", "PNG image"));
				fc.addChoosableFileFilter(new OpenFileFilter("svg", "Scalable Vector Graphic"));
				fc.setAcceptAllFileFilterUsed(false);
				int returnVal = fc.showOpenDialog(ProductFrame.this);
				if (returnVal == JFileChooser.APPROVE_OPTION)
				{
					File f = fc.getSelectedFile();
					try
					{
						BufferedImage bimg = ImageIO.read(f);
						ImagePanel.setImage(bimg);
					} catch (IOException e1)
					{
						e1.printStackTrace();
					}
				}
				load();
			}
		});
		btnBrowseImg.setBounds(638, 435, 117, 29);
		contentPane.add(btnBrowseImg);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainFrame().setVisible(true);
			}
		});
		btnBack.setBounds(6, 7, 117, 29);
		contentPane.add(btnBack);
		
		load();
	}

	public void load() 
	{

		try
		{
			list = ProductManager.getAllProduct();
			DefaultTableModel model = new DefaultTableModel();
			model.addColumn("product_id");
			model.addColumn("product_name");
			model.addColumn("price_per_unit");
			model.addColumn("product_description");

			for (ProductDB c : list)
			{
				model.addRow(new Object[]
				{ c.product_id, c.product_name, c.price_per_unit, c.product_description });
			}

			table.setModel(model);
		} catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}

class OpenFileFilter extends FileFilter
{

	String description = "";
	String fileExt = "";

	public OpenFileFilter(String extension)
	{
		fileExt = extension;
	}

	public OpenFileFilter(String extension, String typeDescription)
	{
		fileExt = extension;
		this.description = typeDescription;
	}

	@Override
	public boolean accept(File f)
	{
		if (f.isDirectory())
			return true;
		return (f.getName().toLowerCase().endsWith(fileExt));
	}

	@Override
	public String getDescription()
	{
		return description;
	}
}