package v;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import m.CustomerDB;
import m.CustomerManager;
import m.ProductDB;
import m.ProductManager;
import m.UserDB;

import m.UserManager;

import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UserFrame extends JFrame
{

	private JPanel contentPane;
	private JTextField textField_id;
	private JTextField textField_username;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
					
					UserFrame frame = new UserFrame();
					frame.setVisible(true);
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UserFrame()
	{
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 652, 403);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 54, 336, 310);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				if (table.getSelectedRowCount() < 1)
				{
					return;
				}
				int index = table.getSelectedRow();
				int id = Integer.parseInt(table.getValueAt(index, 0).toString());
				String username = table.getValueAt(index, 1).toString();
				String password = table.getValueAt(index, 2).toString();
				String usertype = table.getValueAt(index, 3).toString();

				textField_id.setText("" + id);
				textField_username.setText("" + username);
				textField_password.setText("" + password);
				comboBox.setSelectedItem(usertype);

			}
		});
		scrollPane.setViewportView(table);
		
		JLabel label = new JLabel("id");
		label.setBounds(378, 54, 46, 14);
		contentPane.add(label);
		
		JButton button_delete = new JButton("delete");
		button_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int result = JOptionPane.showConfirmDialog(UserFrame.this, "Please confrim to delete this user",
						"confirm", JOptionPane.OK_CANCEL_OPTION);

				if (result == JOptionPane.OK_OPTION)
				{
					int k = 0;
					if (!textField_id.getText().matches("\\d+"))
					{
						JOptionPane.showMessageDialog(UserFrame.this, "Please select one row on the table");
						return;
					}

					UserDB x = new UserDB(0, textField_username.getText().trim(), textField_password.getText().trim(),
							comboBox.getSelectedItem().toString().trim());
					x.id = Integer.parseInt(textField_id.getText());
					UserManager.deleteUser(x);

					load();
				}
			}
		});
		button_delete.setBounds(485, 271, 89, 23);
		contentPane.add(button_delete);
		
		JLabel lblUsername = new JLabel("username");
		lblUsername.setBounds(378, 79, 70, 14);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("password");
		lblPassword.setBounds(378, 104, 60, 14);
		contentPane.add(lblPassword);
		
		JLabel lblUsertype = new JLabel("usertype");
		lblUsertype.setBounds(378, 129, 46, 14);
		contentPane.add(lblUsertype);
		
		textField_id = new JTextField();
		textField_id.setForeground(Color.PINK);
		textField_id.setColumns(10);
		textField_id.setBounds(485, 54, 127, 20);
		contentPane.add(textField_id);
		
		textField_username = new JTextField();
		textField_username.setColumns(10);
		textField_username.setBounds(485, 79, 127, 20);
		contentPane.add(textField_username);
		
		JButton button_save = new JButton("save new");
		button_save.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				UserDB x = new UserDB(0, textField_username.getText().trim(), textField_password.getText().trim(),
						comboBox.getSelectedItem().toString().trim());
				UserManager.saveUser(x);
				load();
				textField_id.setText("");
				textField_username.setText("");
				textField_password.setText("");
				//����ͧ���combobox
		
				JOptionPane.showMessageDialog(UserFrame.this, "User saved");
			}
		});
		
		textField_password = new JTextField();
		textField_password.setBounds(485, 101, 127, 23);
		contentPane.add(textField_password);
		textField_password.setColumns(10);
		button_save.setBounds(485, 174, 89, 23);
		contentPane.add(button_save);
		
		JButton button_edit = new JButton("edit");
		button_edit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				UserDB x = new UserDB(0, textField_username.getText().trim(), textField_password.getText().trim(),
						comboBox.getSelectedItem().toString().trim());
				x.id = Integer.parseInt(textField_id.getText());
				x.username = new String(textField_username.getText());
				x.password = new String(textField_password.getText());
				x.usertype = (String) comboBox.getSelectedItem();

				UserManager.editUser(x);
				JOptionPane.showMessageDialog(UserFrame.this, "User updated");

				load();
			}
		});
		button_edit.setBounds(485, 221, 89, 23);
		contentPane.add(button_edit);
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"admin", "users"}));
		comboBox.setBounds(485, 126, 127, 23);
		contentPane.add(comboBox);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainFrame().setVisible(true);
			}
		});
		btnBack.setBounds(6, 13, 117, 29);
		contentPane.add(btnBack);
		
		load();
	}
	
	ArrayList<UserDB> list;
	private JComboBox comboBox;
	private JTextField textField_password;
		public void load()
		{

			list = UserManager.getAllUser();
			DefaultTableModel model = new DefaultTableModel();
			model.addColumn("id");
			model.addColumn("username");
			model.addColumn("password");
			model.addColumn("usertype");

			for (UserDB c : list)
			{
				model.addRow(new Object[]
				{ c.id, c.username, c.password, c.usertype });
			}

			table.setModel(model);
		}
}
