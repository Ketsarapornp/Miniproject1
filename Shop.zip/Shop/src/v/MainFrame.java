package v;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;

public class MainFrame extends JFrame
{

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					try
					{
						// Set System L&F
						UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
					} catch (UnsupportedLookAndFeelException e)
					{
						// handle exception
					} catch (ClassNotFoundException e)
					{
						// handle exception
					} catch (InstantiationException e)
					{
						// handle exception
					} catch (IllegalAccessException e)
					{
						// handle exception
					}
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrame()
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 307);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnNewButton = new JButton("customer");
		btnNewButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				CustomerFrame f = new CustomerFrame();
				f.setVisible(true);
			}
		});
		btnNewButton.setBounds(32, 32, 89, 23);
		contentPane.add(btnNewButton);

		JButton btnProduct = new JButton("product");
		btnProduct.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProductFrame f = new ProductFrame();
				f.setVisible(true);
				
			}
		});
		btnProduct.setBounds(238, 32, 89, 23);
		contentPane.add(btnProduct);

		JButton btnNewButton_1 = new JButton("user");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserFrame f = new UserFrame();
				f.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(431, 32, 89, 23);
		contentPane.add(btnNewButton_1);
		
		JLabel lblWelcomeToMy = new JLabel("Welcome to my ShoeShop");
		lblWelcomeToMy.setFont(new Font("Lucida Grande", Font.BOLD, 27));
		lblWelcomeToMy.setBounds(119, 125, 401, 32);
		contentPane.add(lblWelcomeToMy);
	}
}
