package v;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import m.CustomerDB;
import m.CustomerManager;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CustomerFrame extends JFrame
{

	private JPanel contentPane;
	private JTable table;
	private JTextField txt_id;
	private JTextField txt_name;
	private JTextField txt_surname;
	private JTextField txt_phone;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					CustomerFrame frame = new CustomerFrame();
					frame.setVisible(true);
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustomerFrame()
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 649, 413);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(24, 29, 340, 330);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if (table.getSelectedRowCount() < 1)
				{
					return;
				}
				int index = table.getSelectedRow();
				int id = Integer.parseInt(table.getValueAt(index, 0).toString());
				String name = table.getValueAt(index, 1).toString();
				String surname = table.getValueAt(index, 2).toString();
				String phone = table.getValueAt(index, 3).toString();

				txt_id.setText("" + id);
				txt_name.setText("" + name);
				txt_surname.setText("" + surname);
				txt_phone.setText("" + phone);
			}
		});
		scrollPane.setViewportView(table);
		
		JLabel lblId = new JLabel("ID");
		lblId.setBounds(376, 43, 61, 16);
		contentPane.add(lblId);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(376, 79, 61, 16);
		contentPane.add(lblName);
		
		JLabel lblLastname = new JLabel("Surname");
		lblLastname.setBounds(376, 123, 61, 16);
		contentPane.add(lblLastname);
		
		JLabel lblPhone = new JLabel("Phone");
		lblPhone.setBounds(376, 163, 61, 16);
		contentPane.add(lblPhone);
		
		txt_id = new JTextField();
		txt_id.setBounds(449, 38, 130, 26);
		contentPane.add(txt_id);
		txt_id.setColumns(10);
		
		txt_name = new JTextField();
		txt_name.setColumns(10);
		txt_name.setBounds(449, 74, 130, 26);
		contentPane.add(txt_name);
		
		txt_surname = new JTextField();
		txt_surname.setColumns(10);
		txt_surname.setBounds(449, 118, 130, 26);
		contentPane.add(txt_surname);
		
		txt_phone = new JTextField();
		txt_phone.setColumns(10);
		txt_phone.setBounds(449, 158, 130, 26);
		contentPane.add(txt_phone);
		
	
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.OK_OPTION == JOptionPane.showConfirmDialog(CustomerFrame.this, "Confirm user deletion",
						"DELETE ?", JOptionPane.OK_CANCEL_OPTION))
				{

					CustomerDB x = new CustomerDB(Integer.parseInt(txt_id.getText()), txt_name.getText().trim(),
							txt_surname.getText().trim(), txt_phone.getText().trim());
					CustomerManager.deleteCustomer(x);
					load();
					txt_id.setText("");
					txt_name.setText("");
					txt_surname.setText("");
					txt_phone.setText("");

					JOptionPane.showMessageDialog(CustomerFrame.this, "User deleted");
				}
			}
		});
		btnDelete.setBounds(449, 265, 117, 29);
		contentPane.add(btnDelete);
		
		JButton btnSaveNew = new JButton("Save");
		btnSaveNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustomerDB x = new CustomerDB(0, txt_name.getText().trim(), txt_surname.getText().trim(),
						txt_phone.getText().trim());
				CustomerManager.saveNewCustomer(x);
				load();
				txt_id.setText("");
				txt_name.setText("");
				txt_surname.setText("");
				txt_phone.setText("");

				JOptionPane.showMessageDialog(CustomerFrame.this, "User saved");
			}
		});
		btnSaveNew.setBounds(449, 224, 117, 29);
		contentPane.add(btnSaveNew);
		
		JButton btnEdit = new JButton("Edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustomerDB x = new CustomerDB(Integer.parseInt(txt_id.getText()), txt_name.getText().trim(),
						txt_surname.getText().trim(), txt_phone.getText().trim());
				CustomerManager.editCustomer(x);
				load();
				txt_id.setText("");
				txt_name.setText("");
				txt_surname.setText("");
				txt_phone.setText("");

				JOptionPane.showMessageDialog(CustomerFrame.this, "User edited");
			}
		});
		btnEdit.setBounds(449, 306, 117, 29);
		contentPane.add(btnEdit);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainFrame().setVisible(true);
			}
		});
		btnBack.setBounds(526, 356, 117, 29);
		contentPane.add(btnBack);
		
		load();
	}
	ArrayList<CustomerDB> list;
	public void load()
	{
		try
		{
			list = CustomerManager.getAllCustomer();
			DefaultTableModel model = new DefaultTableModel();
			model.addColumn("id");
			model.addColumn("name");
			model.addColumn("surname");
			model.addColumn("phone");

			for (CustomerDB c : list)
			{
				model.addRow(new Object[]
				{ c.id, c.name, c.surname, c.phone });
			}

			table.setModel(model);
		} catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
