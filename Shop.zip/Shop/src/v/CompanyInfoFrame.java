package v;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import m.CompanyInfoDB;
import m.CompanyInfoManager;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CompanyInfoFrame extends JFrame
{

	private JPanel contentPane;
	private JTextField textField_name;
	private JTextField textField_add;
	private JTextField textField_phone;
	private JTextField textField_email;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable()
		{
			public void run()
			{
				try
				{
					CompanyInfoFrame frame = new CompanyInfoFrame();
					frame.setVisible(true);
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CompanyInfoFrame()
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 840, 424);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCompany = new JLabel("Company");
		lblCompany.setFont(new Font("Lucida Grande", Font.BOLD, 25));
		lblCompany.setBounds(356, 28, 231, 46);
		contentPane.add(lblCompany);
		
		JLabel lblCompanyName = new JLabel("Company name");
		lblCompanyName.setBounds(47, 107, 135, 16);
		contentPane.add(lblCompanyName);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setBounds(47, 154, 135, 16);
		contentPane.add(lblAddress);
		
		JLabel lblPhone = new JLabel("Phone");
		lblPhone.setBounds(47, 198, 135, 16);
		contentPane.add(lblPhone);
		
		JLabel lblEmail = new JLabel("Email");
		lblEmail.setBounds(47, 246, 135, 16);
		contentPane.add(lblEmail);
		
		textField_name = new JTextField();
		textField_name.setBounds(244, 102, 488, 26);
		contentPane.add(textField_name);
		textField_name.setColumns(10);
		
		textField_add = new JTextField();
		textField_add.setColumns(10);
		textField_add.setBounds(244, 149, 488, 26);
		contentPane.add(textField_add);
		
		textField_phone = new JTextField();
		textField_phone.setColumns(10);
		textField_phone.setBounds(244, 193, 488, 26);
		contentPane.add(textField_phone);
		
		textField_email = new JTextField();
		textField_email.setColumns(10);
		textField_email.setBounds(244, 241, 488, 26);
		contentPane.add(textField_email);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				xCompanyInfoDB.company_name = textField_name.getText();
				xCompanyInfoDB.address = textField_add.getText();
				xCompanyInfoDB.phone = textField_phone.getText();
				xCompanyInfoDB.email = textField_email.getText();
				CompanyInfoManager.editCompanyInfo(xCompanyInfoDB);
			}
		});
		btnSave.setBounds(615, 328, 117, 29);
		contentPane.add(btnSave);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MainFrame().setVisible(true);
			}
		});
		btnBack.setBounds(701, 6, 117, 29);
		contentPane.add(btnBack);
		load();
	}
	CompanyInfoDB xCompanyInfoDB;
	public void load()
	{
		xCompanyInfoDB = CompanyInfoManager.getCompanyInfo();
		textField_name.setText(xCompanyInfoDB.company_name);
		textField_add.setText(xCompanyInfoDB.address);
		textField_phone.setText(xCompanyInfoDB.phone);
		textField_email.setText(xCompanyInfoDB.email);
	}

}
