package c;

public class GlobalData
{
	
	
	public static String CurrentUser_username;
	public static int CurrentUser_userID;
	public static String CurrentUser_usertype;

}
